<?php

	include_once('functions.php');	

	$data = $_GET['data'];
	$json_decode = json_decode($data, true);
	echo 'Code:'.$json_decode['code'].'<br>';
	 echo  'User Acc No :'.$json_decode['sender_no'].'<br>';
	echo 'Merchant : '.$json_decode['receiver_no'].'<br>';
	echo 'Amount :'.$json_decode['amount'].'<br>';
	echo 'Status code :'.$json_decode['status_code'].'<br>';
	echo 'Date & time :'.$json_decode['time'].'<br>';

	if($json_decode['status_code']==000){
		echo "Transfer initialized.";
	}
	elseif ($json_decode['status_code']==001) {
		echo "Transfer is ready.";
	}
	elseif ($json_decode['status_code']==011) {
		echo "Transfer was failed. Sender not found.";
	}
	elseif ($json_decode['status_code']==012) {
		echo "Transfer was failed. Incompatible sender.";
	}
	elseif ($json_decode['status_code']==013) {
		echo "Transfer was failed. Not enough balance.";
	}
	elseif ($json_decode['status_code']==012) {
		echo "Transfer was failed. Incompatible sender.";
	}elseif ($json_decode['status_code']==021) {
		echo "Transfer was failed. Receiver not found.";
	}elseif ($json_decode['status_code']==022) {
		echo "Transfer was failed. Incompatible receiver.";
	}elseif ($json_decode['status_code']==100) {
		echo "Transfer was executed successfully.";
	}
	  
	  ?>
	<!-- <script>







	function statuscode ($status_code){
		<script>
	$status_code = $_POST['status_code'];
		var status_code;
		switch (new statuscode().getStatusCode()) {
   	 case 000:
        status_code = "Transfer initialized.";
        break;
    case 001:
        status_code = "Transfer is ready.";
        break;
    case 011:
        status_code = "Transfer was failed. Sender not found.";
        break;
    case 012:
        status_code = "Transfer was failed. Incompatible sender.";
        break;
    case 013:
        status_code = "Transfer was failed. Not enough balance.";
        break;
    case 021:
        status_code = "Transfer was failed. Receiver not found.";
        break;
    case  022:
       status_code = "Transfer was failed. Incompatible receiver.";

     case  100:
       status_code = "Transfer was executed successfully.";  
}
document.getElementById("status_code").innerHTML = " Payment Status " + status_code;
</script> -->
	


